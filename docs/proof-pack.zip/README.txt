Answered security questionnaire: Sample Co
Evidence period: 2026-09-26 to 2026-10-26. Generated 2026-10-28T20:54:14+00:00 by Verifiable Evidence Agent 0.1.0.

Every claim in these answers cites evidence records that Sample Co sealed when they were collected. This pack
contains exactly those records, byte for byte, and the proofs that they are unchanged since sealing.

How to check it
  1. Open answers.html in a browser. It recomputes every hash and Merkle proof on your machine and shows the
     result next to each answer. Nothing is sent anywhere.
  2. Or run the standalone verifier (Python 3, standard library only):  python verify_pack.py <this zip>

What the checks prove
  Each cited record's content matches its sealed hash, its hash-chain link is intact, and it is included in the
  sealed batch whose root is printed by the verifier. Every file matches manifest.json.

Who sealed it
  Every sealed batch is signed by the key with SHA-256 fingerprint 3a43cef7bc01614434541a77777626e625375d4cb13bfffdb8d2f28e4b0cdf8d. Compare it with the fingerprint the company publishes, or check it in one step:
  python verify_pack.py <this zip> --key <published fingerprint>

Answers marked DRAFT were not approved by a person before export.
